export default function handler(req, res) {
  const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || "https://saltyanglerstore.com";
  const staticPages = ["/", "/shop", "/lookbook", "/about", "/privacy"];
  const xml = `<?xml version="1.0" encoding="UTF-8"?>
  <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    ${staticPages.map(u => `<url><loc>${baseUrl}${u}</loc></url>`).join('')}
  </urlset>`;
  res.setHeader("Content-Type", "application/xml");
  res.status(200).send(xml);
}

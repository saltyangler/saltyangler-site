export default async function handler(req, res) {
  const shop = process.env.SHOPIFY_STORE_DOMAIN;
  const token = process.env.SHOPIFY_STOREFRONT_TOKEN;
  if (!shop || !token) return res.status(500).json({ ok: false, error: "Missing SHOPIFY env vars" });

  const endpoint = `https://${shop}/api/2024-10/graphql.json`;
  const query = `
    query getProducts($first: Int!) {
      products(first: $first) {
        edges {
          node {
            id
            handle
            title
            description
            images(first: 5) {
              edges { node { url altText } }
            }
            variants(first: 10) {
              edges {
                node {
                  id
                  title
                  priceV2 { amount currencyCode }
                  availableForSale
                }
              }
            }
          }
        }
      }
    }
  `;

  try {
    const resp = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Shopify-Storefront-Access-Token": token,
      },
      body: JSON.stringify({ query, variables: { first: 12 } }),
    });

    const json = await resp.json();
    if (json.errors) return res.status(500).json({ ok: false, errors: json.errors });
    const products = json.data.products.edges.map(e => e.node);
    return res.json({ ok: true, products });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ ok: false, error: err.message });
  }
}

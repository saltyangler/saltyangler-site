export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ ok: false, message: "Method not allowed" });

  const { items } = req.body; // items: [{ variantId, quantity }]
  if (!items || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ ok: false, message: "No items provided" });
  }

  const shop = process.env.SHOPIFY_STORE_DOMAIN;
  const token = process.env.SHOPIFY_STOREFRONT_TOKEN;
  const endpoint = `https://${shop}/api/2024-10/graphql.json`;

  const mutation = `
    mutation checkoutCreate($input: CheckoutCreateInput!) {
      checkoutCreate(input: $input) {
        checkout {
          id
          webUrl
        }
        userErrors { field message }
      }
    }
  `;

  const lineItems = items.map(i => ({
    variantId: i.variantId,
    quantity: i.quantity || 1
  }));

  const variables = { input: { lineItems } };

  try {
    const resp = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Shopify-Storefront-Access-Token": token
      },
      body: JSON.stringify({ query: mutation, variables })
    });

    const json = await resp.json();
    if (json.errors) return res.status(500).json({ ok: false, errors: json.errors });

    const payload = json.data.checkoutCreate;
    if (payload.userErrors && payload.userErrors.length) {
      return res.status(400).json({ ok: false, userErrors: payload.userErrors });
    }

    const webUrl = payload.checkout?.webUrl;
    return res.json({ ok: true, webUrl });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ ok: false, error: err.message });
  }
}

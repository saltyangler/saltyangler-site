import { v2 as cloudinary } from "cloudinary";
import formidable from "formidable";
import fs from "fs";

export const config = { api: { bodyParser: false } };

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

const parseForm = (req) =>
  new Promise((resolve, reject) => {
    const form = new formidable.IncomingForm({ multiples: true, maxFileSize: 10 * 1024 * 1024 });
    form.parse(req, (err, fields, files) => {
      if (err) reject(err);
      else resolve({ fields, files });
    });
  });

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ ok: false, message: "Method not allowed" });

  try {
    const { files } = await parseForm(req);
    if (!files.images) return res.status(400).json({ ok: false, message: "No images uploaded" });

    let images = Array.isArray(files.images) ? files.images : [files.images];
    if (images.length > 6) return res.status(400).json({ ok: false, message: "Max 6 images allowed" });

    const uploadResults = [];
    for (const file of images) {
      const filepath = file.filepath || file.path;
      const result = await cloudinary.uploader.upload(filepath, {
        folder: "saltyangler/submissions",
        resource_type: "image",
        use_filename: true,
        unique_filename: true,
        overwrite: false,
      });
      uploadResults.push({ url: result.secure_url, public_id: result.public_id, width: result.width, height: result.height });
      try { fs.unlinkSync(filepath); } catch (e) { /* ignore */ }
    }

    return res.json({ ok: true, results: uploadResults });
  } catch (err) {
    console.error("upload error:", err);
    return res.status(500).json({ ok: false, error: err.message || "Upload failed" });
  }
}

import { useEffect, useState } from "react";
import SeoHead from "../components/SeoHead";
import { ShoppingCart, Trash2, X, Camera } from "lucide-react";
import { motion } from "framer-motion";

export default function Home() {
  const [products, setProducts] = useState([]);
  const [cart, setCart] = useState([]);
  const [loadingProducts, setLoadingProducts] = useState(true);
  const [category, setCategory] = useState("all");
  const [gallery] = useState([
    { src: "https://images.unsplash.com/photo-1505820013142-f86a3439c5c7", alt: "Tarpon" },
    { src: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38", alt: "Mahi Mahi" },
    { src: "https://images.unsplash.com/photo-1627491342847-9bb4dd47cebb", alt: "Snook" },
    { src: "https://images.unsplash.com/photo-1617957741640-3b6e25a6b39f", alt: "Sailfish" },
    { src: "https://images.unsplash.com/photo-1598970434795-0c54fe7c0648", alt: "Redfish" },
    { src: "https://images.unsplash.com/photo-1578301978693-85a6a3d8aa4b", alt: "Offshore Fishing" },
  ]);
  const [lightbox, setLightbox] = useState(null);
  const [uploadFiles, setUploadFiles] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [uploadedSuccess, setUploadedSuccess] = useState(false);
  const [testimonials] = useState([
    { name: "Mikey", text: "Best gear for Florida salt — survived a week offshore and still looks new." },
    { name: "J. Rivera", text: "Comfortable, breathable, and stylish. Hooked for life." },
  ]);

  useEffect(() => {
    async function load() {
      setLoadingProducts(true);
      try {
        const r = await fetch("/api/shopify/products");
        const j = await r.json();
        if (j.ok) setProducts(j.products || []);
        else console.error("Products error", j);
      } catch (err) {
        console.error("Failed to load products", err);
      } finally {
        setLoadingProducts(false);
      }
    }
    load();
  }, []);

  useEffect(() => {
    if (uploadedSuccess) {
      const t = setTimeout(() => setUploadedSuccess(false), 3500);
      return () => clearTimeout(t);
    }
  }, [uploadedSuccess]);

  function addToCart(item, variantId) {
    const variant = item.variants.edges.find(v => v.node.id === variantId) || item.variants.edges[0];
    const price = variant ? Number(variant.node.priceV2.amount) : 0;
    const image = (item.images && item.images.edges[0] && item.images.edges[0].node.url) || "/logo.png";
    const cartItem = { id: `${item.handle}::${variantId}`, title: `${item.title}${variant?.node?.title ? " - " + variant.node.title : ""}`, price, variantId, quantity: 1, image };
    setCart(prev => [...prev, cartItem]);
  }

  function removeFromCart(index) {
    setCart(prev => prev.filter((_, i) => i !== index));
  }

  function updateQty(index, qty) {
    setCart(prev => prev.map((it, i) => i === index ? { ...it, quantity: Math.max(1, qty) } : it));
  }

  async function handleCheckout() {
    if (cart.length === 0) { alert("Cart is empty"); return; }
    const items = cart.map(c => ({ variantId: c.variantId, quantity: c.quantity }));
    try {
      const res = await fetch("/api/shopify/create-checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ items })
      });
      const j = await res.json();
      if (!j.ok) {
        console.error("Checkout error", j);
        alert("Unable to create checkout. Try again.");
        return;
      }
      window.location.href = j.webUrl;
    } catch (err) {
      console.error(err);
      alert("Checkout failed. See console.");
    }
  }

  function handleFilesSelected(e) {
    const files = Array.from(e.target.files).slice(0, 6);
    const previews = files.map((f) => ({ file: f, url: URL.createObjectURL(f) }));
    setUploadFiles(previews);
    setUploadedSuccess(false);
  }

  async function handleUpload(e) {
    e.preventDefault();
    if (!uploadFiles.length) return;
    setUploading(true);
    const form = new FormData();
    uploadFiles.forEach((p) => form.append("images", p.file, p.file.name));
    form.append("source", "customer-submission");
    try {
      const res = await fetch("/api/upload", { method: "POST", body: form });
      const j = await res.json();
      if (!j.ok) throw new Error(j.error || "Upload failed");
      setUploadedSuccess(true);
      setUploadFiles([]);
    } catch (err) {
      console.error(err);
      alert("Upload failed");
    } finally {
      setUploading(false);
    }
  }

  const total = cart.reduce((s, it) => s + it.price * (it.quantity || 1), 0);

  return (
    <>
      <SeoHead
        title="SaltyAngler — Florida Saltwater Fishing Apparel"
        description="SaltyAngler — gear built for saltwater anglers in Florida. Shop hoodies, tees, and hats built for the salt life."
        url="https://saltyanglerstore.com"
        image="/og-image.jpg"
      />
      <div className="min-h-screen bg-slate-100 text-slate-900">
        {/* NAV */}
        <nav className="flex justify-between items-center p-4 bg-gradient-to-r from-slate-800 to-slate-900 text-white">
          <div className="flex items-center gap-4">
            <img src="/logo.png" alt="SaltyAngler logo" className="h-12 w-auto" />
            <span className="sr-only">SaltyAngler</span>
          </div>
          <div className="flex items-center gap-6">
            <a href="#shop" className="hover:underline">Shop</a>
            <a href="#lookbook" className="hover:underline">Lookbook</a>
            <a href="#share" className="hover:underline">Share</a>
            <a href="#about" className="hover:underline">About</a>
            <a href="#cart" className="hover:underline flex items-center">
              <ShoppingCart className="mr-1" /> <span className="ml-1">({cart.length})</span>
            </a>
          </div>
        </nav>

        {/* HERO */}
        <header className="relative overflow-hidden bg-[linear-gradient(180deg,#01263f,rgba(1,38,63,0.6))] text-white">
          <div className="max-w-7xl mx-auto px-6 py-24 flex flex-col md:flex-row items-center gap-10">
            <div className="flex-1">
              <motion.img src="/logo.png" alt="SaltyAngler logo" className="h-40 w-auto mb-6 mx-auto md:mx-0" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} />
              <motion.h1 className="text-4xl md:text-5xl font-extrabold mb-4" initial={{ x: -20 }} animate={{ x: 0 }}>
                SaltyAngler — Florida Saltwater Fishing Apparel
              </motion.h1>
              <p className="max-w-xl mb-6 text-slate-200">
                Built for anglers who chase tarpon, snook, mahi and offshore monsters. Performance fabrics, sun protection, and classic coastal styling.
              </p>
              <div className="flex gap-4 flex-wrap">
                <a href="#shop" className="px-6 py-3 bg-amber-500 rounded-lg text-white">Shop Our Gear</a>
                <a href="#lookbook" className="px-6 py-3 border border-white rounded-lg">See Lookbook</a>
              </div>
            </div>

            <div className="w-full md:w-1/2 rounded-2xl overflow-hidden shadow-2xl">
              <img src="https://images.unsplash.com/photo-1507525428034-b723cf961d3e?ixlib=rb-4.0.3" alt="ocean" className="w-full h-64 object-cover" />
            </div>
          </div>
        </header>

        {/* SHOP */}
        <section id="shop" className="py-16 px-6 max-w-7xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-8">Shop</h2>

          <div className="flex justify-center mb-8 gap-3">
            {["all", "hoodies", "tees", "hats", "others"].map(c => (
              <button key={c} onClick={() => setCategory(c)} className={`px-4 py-2 rounded-lg ${category === c ? "bg-slate-800 text-white" : "border"}`}>
                {c.charAt(0).toUpperCase() + c.slice(1)}
              </button>
            ))}
          </div>

          {loadingProducts ? (
            <p className="text-center">Loading products…</p>
          ) : (
            <div className="grid md:grid-cols-3 gap-6">
              {products.filter(p => category === "all" || (p.handle || "").includes(category.slice(0, -1))).map(product => {
                const img = product.images?.edges?.[0]?.node?.url || "/logo.png";
                const variants = product.variants?.edges || [];
                return (
                  <div key={product.id} className="bg-white rounded-lg p-4 shadow hover:scale-[1.02] transition-transform">
                    <div className="h-44 overflow-hidden rounded-md mb-4">
                      <img src={img} alt={product.title} className="w-full h-full object-cover" />
                    </div>
                    <h3 className="text-xl font-semibold">{product.title}</h3>
                    <p className="text-slate-600 mt-2">{product.description?.slice(0,120)}</p>

                    <div className="mt-3">
                      <label className="text-sm font-medium">Variant</label>
                      <select className="mt-1 w-full border rounded px-2 py-1" defaultValue={variants[0]?.node?.id} id={`variant-${product.handle}`}>
                        {variants.map((v, i) => (
                          <option key={v.node.id} value={v.node.id}>
                            {v.node.title} — ${v.node.priceV2.amount} {v.node.availableForSale? "" : "(sold out)"}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="mt-4 flex gap-2">
                      <button
                        onClick={() => {
                          const sel = document.getElementById(`variant-${product.handle}`);
                          const variantId = sel ? sel.value : variants[0]?.node?.id;
                          addToCart(product, variantId);
                        }}
                        className="flex-1 px-4 py-2 bg-slate-800 text-white rounded-lg"
                      >
                        Add to Cart
                      </button>

                      <a className="px-3 py-2 border rounded-lg" href={`https://${process.env.NEXT_PUBLIC_BASE_URL || "saltyanglerstore.com"}/products/${product.handle}`} target="_blank" rel="noreferrer">Buy on Shopify</a>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>

        {/* LOOKBOOK */}
        <section id="lookbook" className="py-16 bg-slate-50">
          <div className="max-w-7xl mx-auto px-6">
            <h2 className="text-3xl font-bold text-center mb-8">Lookbook — Saltwater Fish & Angling</h2>
            <div className="grid md:grid-cols-3 gap-6">
              {gallery.map((img, i) => (
                <motion.img key={i} src={img.src} alt={img.alt} className="rounded-2xl shadow-lg cursor-pointer" whileHover={{ scale: 1.02 }} onClick={() => setLightbox(img)} />
              ))}
            </div>
          </div>
        </section>

        {/* SHARE (uploads) */}
        <section id="share" className="py-16 px-6">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-4">Share Your Catch</h2>
            <p className="mb-6 text-slate-600">Upload photos of you wearing SaltyAngler on your saltwater trips — we may feature the best shots in our gallery and socials.</p>

            <form onSubmit={handleUpload} className="space-y-4">
              <label className="inline-flex items-center gap-2 cursor-pointer">
                <Camera /> <span className="text-sm">Choose up to 6 images (JPEG/PNG)</span>
                <input aria-label="Upload photos" type="file" accept="image/*" multiple onChange={handleFilesSelected} className="sr-only" />
              </label>

              {uploadFiles.length > 0 && (
                <div className="grid grid-cols-3 gap-3">
                  {uploadFiles.map((p, idx) => (
                    <div key={idx} className="relative">
                      <img src={p.url} alt={`preview-${idx}`} className="rounded-lg object-cover h-32 w-full" />
                      <button type="button" onClick={() => setUploadFiles(uploadFiles.filter((_, i) => i !== idx))} className="absolute top-1 right-1 bg-white rounded-full p-1">
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              <div className="flex justify-center">
                <button type="submit" disabled={uploading} className="px-6 py-3 bg-emerald-600 text-white rounded-lg">{uploading ? "Uploading..." : "Submit Photos"}</button>
              </div>

              {uploadedSuccess && <p className="text-green-600">Thanks! Your photos were submitted.</p>}
            </form>

            <p className="text-xs text-slate-500 mt-4">By submitting you agree we may use your images for marketing. Do not upload photos with third-party copyrighted logos or sensitive content.</p>
          </div>
        </section>

        {/* LIGHTBOX */}
        {lightbox && (
          <div className="fixed inset-0 bg-black bg-opacity-80 z-50 flex items-center justify-center p-4">
            <div className="relative max-w-4xl w-full">
              <button onClick={() => setLightbox(null)} className="absolute top-3 right-3 p-2 bg-white rounded-full"><X /></button>
              <img src={lightbox.src} alt={lightbox.alt} className="w-full rounded-lg object-contain max-h-[80vh] mx-auto" />
              <p className="text-center text-white mt-3">{lightbox.alt}</p>
            </div>
          </div>
        )}

        {/* CART */}
        <section id="cart" className="py-12 px-6 bg-slate-100">
          <div className="max-w-lg mx-auto bg-white rounded-2xl p-6 shadow">
            <h2 className="text-2xl font-bold mb-4">Your Cart</h2>
            {cart.length === 0 ? <p>Your cart is empty.</p> : (
              <div>
                {cart.map((c, i) => (
                  <div key={c.id} className="flex justify-between items-center py-2 border-b">
                    <div className="flex items-center gap-3">
                      <img src={c.image} alt={c.title} className="w-14 h-14 object-cover rounded" />
                      <div>
                        <div className="font-medium">{c.title}</div>
                        <div className="text-sm text-slate-500">${c.price}</div>
                        <div className="mt-1">
                          <label className="text-xs">Qty</label>
                          <input type="number" value={c.quantity} min={1} onChange={(e) => updateQty(i, Number(e.target.value) || 1)} className="w-16 ml-2 border rounded px-2 py-1 text-sm" />
                        </div>
                      </div>
                    </div>
                    <button onClick={() => removeFromCart(i)} className="text-red-500"><Trash2 /></button>
                  </div>
                ))}
                <div className="text-right font-bold mt-4">Total: ${total.toFixed(2)}</div>
                <div className="mt-4">
                  <button onClick={handleCheckout} className="w-full px-4 py-3 bg-blue-700 text-white rounded-lg">Checkout</button>
                </div>
              </div>
            )}
          </div>
        </section>

        {/* TESTIMONIALS */}
        <section className="py-12 px-6">
          <div className="max-w-5xl mx-auto">
            <h3 className="text-2xl font-bold text-center mb-6">What Anglers Say</h3>
            <div className="grid md:grid-cols-2 gap-6">
              {testimonials.map((t, i) => (
                <div key={i} className="bg-white rounded-lg p-4 shadow">
                  <p className="italic">"{t.text}"</p>
                  <div className="mt-3 font-semibold">— {t.name}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ABOUT + FOOTER */}
        <section id="about" className="py-12 px-6 text-center">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-2xl font-bold mb-4">Born in Florida — Saltwater Only</h2>
            <p className="text-slate-600">SaltyAngler exists to outfit Florida anglers chasing inshore and offshore saltwater species. UV protection, quick-dry fabrics, and designs inspired by the sea.</p>
          </div>
        </section>

        <footer className="bg-slate-900 text-white text-center p-6 mt-8">
          <img src="/logo.png" alt="SaltyAngler logo" className="h-10 mx-auto mb-2" />
          <p className="text-sm">© {new Date().getFullYear()} SaltyAngler · Based in Florida · Saltwater fishing apparel</p>
        </footer>
      </div>
    </>
  );
}

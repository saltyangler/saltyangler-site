# SaltyAngler — Next.js storefront (starter)

## Quick start
1. Copy this folder to your machine or use the provided ZIP.
2. Install dependencies: `npm install`
3. Create `.env.local` from `.env.example` and fill in credentials.
4. Run locally: `npm run dev`
5. Deploy to Vercel and set environment variables in the Vercel dashboard.

## Notes
- Replace public/logo.png and public/og-image.jpg with your final assets.
- Add hero video to public/hero.mp4 and fallback image public/hero-fallback.jpg

import Head from "next/head";

export default function SeoHead({ title = "SaltyAngler", description, url, image }) {
  const desc = description || "SaltyAngler — Florida saltwater fishing apparel.";
  const pageUrl = url || process.env.NEXT_PUBLIC_BASE_URL || "https://saltyanglerstore.com";
  const img = image || `${pageUrl}/og-image.jpg`;

  return (
    <Head>
      <title>{title}</title>
      <meta name="description" content={desc} />
      <meta property="og:title" content={title} />
      <meta property="og:description" content={desc} />
      <meta property="og:type" content="website" />
      <meta property="og:url" content={pageUrl} />
      <meta property="og:image" content={img} />
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={title} />
      <meta name="twitter:description" content={desc} />
      <meta name="twitter:image" content={img} />
      <link rel="icon" href="/favicon.ico" />
    </Head>
  );
}

# SaltyAngler Store

This is the Next.js website for SaltyAngler, connected to Shopify.

## Setup
1. Run `npm install`
2. Copy `.env.local.example` → `.env.local`
3. Run `npm run dev` to preview locally.
4. Deploy to Vercel and connect your domain saltyanglerstore.com

Your Shopify products will load automatically using the Storefront API.
